<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;
use DB;
class ProdukSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('produk')->delete();
        Product::create([
          'id' => 1,
          'nama' => "Cappucino Latte",
          'harga' => 25000,
          'jumlah' =>100,
          'status'=> 1
        ]);

        Product::create([
          'id' => 2,
          'nama' => "Iced Coffe",
          'harga' => 35000,
          'jumlah' =>100,
          'status'=> 1
        ]);

        Product::create([
          'id' => 3,
          'nama' => "Lemon Tea",
          'harga' => 20000,
          'jumlah' =>100,
          'status'=> 1
        ]);

        Product::create([
          'id' => 4,
          'nama' => "Iced Lemon",
          'harga' => 25000,
          'jumlah' =>100,
          'status'=> 1
        ]);

    }
}
