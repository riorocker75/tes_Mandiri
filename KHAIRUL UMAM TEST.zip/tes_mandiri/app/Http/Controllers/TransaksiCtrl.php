<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Str;

use Illuminate\Support\Facades\Hash;



use App\Models\Transaksi;

class TransaksiCtrl extends Controller
{
   
    


    function index(){
        return view('frontend.index');
    }

    function transaksi_act(Request $request){
        $request->validate([
            'nama' => 'required',
            'pembeli' => 'required',
        ]);

         $date=date('Y-m-d');

         DB::table('transaksi')->insert([
            'nama' => $request->nama,
            'harga'=> $request->harga,
            'jumlah' => $request->jumlah,
            'total'=> $request->total,
            'pembeli'=> $request->pembeli,
            'tanggal' => $date,
            'status' => 1
        ]);

        return redirect('/transaksi')->with('alert-success','Pesanan Anda telah Terkirim');

    }


    

}
