<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Str;

use Illuminate\Support\Facades\Hash;



use App\Models\Transaksi;
use App\Models\User;
use App\Models\Admin;
use App\Models\Product;









class AdminCtrl extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

	public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if(!Session::get('login-adm')){
                return redirect('/login')->with('alert-danger','Dilarang Masuk Terlarang');
            }
            return $next($request);
        });
        
    }
    public function __invoke(Request $request)
    {
       

    }

    function index(){
          return view('admin.admin');
    }

    // anggota

    function anggota(){
        $data= Anggota::orderBy('id','desc')->get();
        return view('admin.anggota_data',[
            'data' => $data
        ]);
    }
    function anggota_act(Request $request){
        $request->validate([
            'nama' => 'required',
        ]);

         $date=date('Y-m-d');

         DB::table('anggota')->insert([
            'nama' => $request->nama,
            'tanggal_lahir'=> $request->tgl_lhr,
            'tempat_lahir' => $request->tmp_lhr,
            'jenis_kelamin'=> $request->kelamin,
            'tingkatan'=> $request->tingkatan,
            'tahun_masuk'=> $request->tahun_masuk,
            'tanggal' => $date,
            'status' => 1
        ]);

        return redirect('/dashboard/anggota/data')->with('alert-success','Data diri anda sudah terkirim');

    }
   

    // transaksi

    function transaksi(){}
    function transaksi_act(){}
    function transaksi_edit(){}

    function transaksi_update(){}
    function transaksi_delete($id){
        Transaksi::where('id',$id)->delete();
        return redirect('/')->with('alert-success','Data terhapus');

    }


    function produk(){
        $data = Product::orderBy('id','desc')->get();
        return view('admin.produk_data',[
            'data' =>$data
        ]);
    }

    function produk_act(Request $request){
        $request->validate([
            'nama' => 'required',
        ]);


         DB::table('produk')->insert([
            'nama' => $request->nama,
            'harga' => $request->harga,
            'status' => 1
        ]);

        return redirect('/dashboard/produk/data')->with('alert-success','Data diri anda sudah terkirim');

    }



    

    // buku sekolah
    function buku_sekolah(){
        $data= Buku::where('jenis',1)->orderBy('id','desc')->get();
        return view('admin.buku_sekolah_data',[
            'data' => $data
        ]);

    }
    function buku_sekolah_act(Request $request){
        $request->validate([
            'judul' => 'required',
        ]);

        $date=date('Y-m-d h:i:s');

         DB::table('buku')->insert([
            'judul' => $request->judul,
            'penulis'=> $request->penulis,
            'penerbit' => $request->penerbit,
            'tahun_terbit'=> $request->tahun_terbit,
            'jumlah'=> $request->jumlah,
            'lokasi'=> $request->lokasi,
            'jenis'=> 1,
            'tanggal' => $date,
            'status' => 1
        ]);

        return redirect('/dashboard/buku_sekolah/data')->with('alert-success','Data diri anda sudah terkirim');

    }
    function buku_sekolah_add(){
        return view('admin.buku_sekolah_add');
    }
    function buku_sekolah_edit($id){
        $data=Buku::where('id',$id)->get();
        return view('admin.buku_sekolah_edit',[
            'data' => $data
        ]);
    }
    function buku_sekolah_update(Request $request){
        $request->validate([
            'judul' => 'required',
        ]);
        $id=$request->id;
       

         DB::table('buku')->where('id',$id)->update([
            'judul' => $request->judul,
            'penulis'=> $request->penulis,
            'penerbit' => $request->penerbit,
            'tahun_terbit'=> $request->tahun_terbit,
            'jumlah'=> $request->jumlah,
            'lokasi'=> $request->lokasi
        ]);

        return redirect('/dashboard/buku_sekolah/data')->with('alert-success','Data diri anda sudah terkirim');
    
    }
    function buku_sekolah_delete($id){
        Buku::where('id',$id)->delete();
        return redirect('/dashboard/buku_sekolah/data')->with('alert-success','Data diri anda sudah terkirim');

    }


 function role(){
     $data=Admin::orderBy('id','asc')->get();
     return view('admin.r_role_data',[
         'data' =>$data
     ]);
 }

  function role_edit($id){
     $data_user=Admin::where('id',$id)->first();
     $data=Admin::orderBy('id','asc')->get();

     return view('admin.r_role_data',[
         'data' =>$data,
         'd_user' =>$data_user
     ]);
 }

  function role_update(Request $request){
    $request->validate([
         'username' => 'required',
         'password' => 'required',
         'role' => 'required',
    ]);
    $cek_admin=Admin::where('level',1)->count();
    $cek_kapus=Admin::where('level',2)->count();

    if($cek_admin < 3 || $cek_kapus < 1){
        if($request->role == 1){
            Admin::insert([
                'username' => $request->username,
                'password' => bcrypt($request->password),
                'level' => 1,
                'status' => 1,
            ]);
     return redirect('/dashboard/role/data')->with('alert-success','data telah berhasil ditambahkan');

         }elseif($request->role == 2){
        Admin::insert([
             'username' => $request->username,
            'password' => bcrypt($request->password),
            'level' => 2,
            'status' => 1
        ]);
     return redirect('/dashboard/role/data')->with('alert-success','data telah berhasil ditambahkan');

    }
    }else{

     return redirect('/dashboard/role/data')->with('alert-success','maaf data sudah maksimal');

    }
    
 }

 function role_delete($id){
     Admin::where('id',$id)->delete();
     return redirect('/dashboard/role/data')->with('alert-success','Data telah terhapus');

 }



 function pengaturan(){
     $username= Session::get('adm_username');
    $data= Admin::where('username',$username)->first();
    return view('admin.pengaturan',[
        'data'=> $data
    ]);

 }

  function pengaturan_update(Request $request){
     $username= Session::get('adm_username');
   
     if($request->password == ""){
        return redirect('/dashboard')->with('alert-success','Tidak Ada perubahan');
     }else{
         Admin::where('level','1')->update([
             'password' =>bcrypt($request->password)
         ]);
        return redirect('/dashboard/pengaturan/data')->with('alert-success','Password telah berubah');

     }

 }






}
